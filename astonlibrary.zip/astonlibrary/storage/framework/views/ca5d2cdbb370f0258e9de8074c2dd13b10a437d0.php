<?php $__env->startSection('content'); ?>

<div class="container">
  <?php if(!$filtered and (count($orders)>0)): ?>

  <button type="button" class="btn btn-block btn-primary" data-toggle="modal" data-target="#filterModal">
    Filter results
  </button>
  <?php endif; ?>
  <?php if($filtered==true and (count($orders)>0)): ?>
  <form action="<?php echo e(route('order.index')); ?>">
    <button type="submit" class="btn btn-block btn-danger">
      Clear filter
    </button>
  </form>
  <?php endif; ?>
  <!-- modal filter panel -->
  <?php if(auth()->guard()->check()): ?>
  <?php if(count($orders)>0): ?>
  <div class="modal fade " id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg ">
      <div class="modal-content bg-dark">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Filter orders</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('order.index')); ?>" method="GET">
          <div class="modal-body card card-body bg-dark text-light">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="filter" value=<?php echo e(true); ?> />
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-all-orders')): ?>
            <div class="form-group">
              <label for="email">Email address</label>
              <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                autocomplete="email">
              <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
              <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <?php endif; ?>
            <div class="form-group">
              <label for="description">Filter by order total less than (GBP)</label>
              <input name="price_lower" class="form-control" type="number" min="0.00" step="1.00" max="2500" />
            </div>
            <div class="form-group">
              <label for="description">Filter by order total greater than (GBP)</label>
              <input name="price_upper" class="form-control" type="number" min="0.00" step="1.00" max="2500" />
            </div>
            <div class="form-group">
              <label for="date_start">Date starting:</label>
              <input type="datetime-local" id="date_start" name="date_start">
              <label for="birthday">Date ending:</label>
              <input type="datetime-local" id="date_end" name="date_end">
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-block btn-primary">Filter</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <table class="table table-dark table-striped">
    <thead class="thead-dark">
      <tr>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
        <th>Email</th>
        <th scope="col">Books</th>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total'));?></th>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('updated_at','Date order made'));?></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($order->id); ?></th>
        <td><?php echo e($order->user->email); ?></td>
        <td>
          <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><?php echo e($book->name); ?> X <?php echo e($book->pivot->quantity); ?> = <?php echo e($book->pivot->sub_total); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><?php echo e($order->total); ?></td>
        <td><?php echo e($order->updated_at); ?>

      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo $orders->appends(\Request::except('page'))->render(); ?>

  <?php elseif($filtered): ?>
  <div class="card card-body bg-dark">
    <h1 class="text-center">Couldn't find any orders for that criteria</h1>
    <form action="<?php echo e(route('order.index')); ?>">
      <button type="submit" class="btn btn-block btn-danger">
        Clear filter
      </button>
    </form>
  </div>
  <?php else: ?>
  <div class='card card-body bg-dark'>
    <h1 class='text-center'> You haven't made any orders yet - we would love for you to start today!</h1>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/order/index.blade.php ENDPATH**/ ?>