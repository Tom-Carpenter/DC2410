<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-authors')): ?>
    <div class="card card-body bg-dark text-center">
        <form action="<?php echo e(route('admin.authors.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="name">Enter the authors name: </label>
            <input id="name" type="text" class="form-control" name="name" required>
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <div class="error text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

            <br />
            <button type="submit" class="btn btn-primary btn-block"> Add author </button>
        </form>
        <h1> Existing authors </h1>
        <div id="list-authors" class="list-group" style="max-height:50vh;overflow:scroll;">
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="list-group-item list-group-item-action text-dark">
                <h5><?php echo e($author->name); ?></h5>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/admin/authors/create.blade.php ENDPATH**/ ?>