<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php if(session('warning')): ?>
<div class="alert alert-warning" role="alert">
    <?php echo e(session('warning')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('info')): ?>
<div class="alert alert-info" role="alert">
    <?php echo e(session('info')); ?>

</div>
<?php endif; ?>

<!-- allows me to use session flashes of alerts --><?php /**PATH /home/u-180203857/astonlibrary/resources/views/partials/alerts.blade.php ENDPATH**/ ?>