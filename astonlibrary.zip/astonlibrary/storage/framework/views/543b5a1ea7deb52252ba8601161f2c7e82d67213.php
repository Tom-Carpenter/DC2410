<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-images')): ?>
<div class="card card-body bg-dark ">
    <form action="<?php echo e(route('admin.images.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <div class="form-check">
                <label for="selectedBook">Select a book to upload image for</label>
                <select name="book" class="form-control" id="selectedBook">
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($book->id); ?>"><?php echo e($book->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="fileToUpload">Select an image to upload</label>
            <input class="form-control-file" type="file" name="fileToUpload" id="fileToUpload" />
        </div>
        <?php if(isset($path)): ?>
        <h1> You uploaded </h1>
        <img src="<?php echo e($path); ?>" alt="preview_image" class="d-block w-100">
        <?php endif; ?>
        <button class="btn btn-span btn-primary" type="submit" value="Upload Image" name="submit">Upload</button>
    </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/admin/images/create.blade.php ENDPATH**/ ?>