<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-images')): ?>
<div class="card card-body bg-dark">
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" style="height:40vh;max-height:40vh;max-width:15vw;width:15vw;overflow:hidden;">
  <div class="carousel-inner container">
  <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($image==$images[0]): ?>
        <div class="carousel-item active">
            <img class="d-block W-100" src="https://astonbookstore.s3.eu-west-2.amazonaws.com/<?php echo e($image->name); ?>" alt="pic">
        </div>
        <?php else: ?>
        <div class="carousel-item">
            <img class="d-block w-100" src="https://astonbookstore.s3.eu-west-2.amazonaws.com/<?php echo e($image->name); ?>" alt="pic">
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/admin/images/index.blade.php ENDPATH**/ ?>