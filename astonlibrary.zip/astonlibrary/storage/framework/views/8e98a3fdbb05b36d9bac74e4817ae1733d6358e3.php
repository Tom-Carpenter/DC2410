<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-books')): ?>
<div class="card bg-dark card-body">
  <h1 class="card-title">Add a new book</h1>
  <div class="modal fade" id="authorModal" tabindex="-1" role="dialog" aria-labelledby="authorModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content bg-dark">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">New author</h5>
          <button type="button btn btn-danger" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="container">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-authors')): ?>
            <div class="card card-body bg-dark text-center">
              <form action="<?php echo e(route('admin.authors.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(true); ?>" name="book" />
                <label for="name">Enter the authors name: </label>
                <input id="name" type="text" class="form-control" name="name" required>
                <br />
                <button type="submit" class="btn btn-primary btn-block"> Add author </button>
              </form>
              <?php endif; ?>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger btn-block" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <form action="<?php echo e(route('admin.books.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="button" class="btn btn-success btn-block" data-toggle="modal" data-target="#authorModal">
      Add a new author
    </button>
    <div class="form-group">
      <label for="name">Name:</label>
      <input required name="name" type="name" class="form-control" id="bookname">
      <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
      <div class="error text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

    </div>
    <div class="form-group">
      <label for="description">Description:</label>
      <textarea required name="description" class="form-control" id="description"></textarea>
      <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
      <div class="error text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

    </div>
    <div class="form-group">
      <label for="description">Price: (GBP)</label>
      <input required name="price" class="form-control" type="number" min="0.00" step="0.10" max="2500" value="0.0" />
      <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
      <div class="error text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="form-group">
      <label for="yearPublished">Year published:</label>
      <input required name="yearPublished" pattern="^[0-9]*$" type="number" min="0000" max="2300" step="1"
        value="2020" />
      <?php if ($errors->has('yearPublished')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('yearPublished'); ?>
      <div class="error text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

    </div>
    <div class="form-group">
      <label for="description">Stock:</label>
      <input required name="stock" pattern="^[0-9]*$" class="form-control" type="number" min="0" step="1" max="1000"
        value="0" />
      <?php if ($errors->has('stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stock'); ?>
      <div class="error text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

    </div>
    <div class="form-group">
      <label>Select any existing authors (hold ctrl to select multiple)</label>
      <select multiple="multiple" name="authors[]" class="custom-select" size="10">
        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option type="checkbox" value="<?php echo e($author->id); ?>"><?php echo e($author->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <div class="form-group">
        <label>Select the relevant categories</label>
        <div class="form-group">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-check">
            <input type="checkbox" name="categories[]" class="form-check-input" value="<?php echo e($category->id); ?>">
            <label class="form-check-label" for="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <button type="submit" class="btn btn-block btn-primary">Add new book</button>
      <a href="javascript:history.back()" class="btn btn-block btn-danger">Cancel</a>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views//admin/books/create.blade.php ENDPATH**/ ?>