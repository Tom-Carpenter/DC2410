<?php $__env->startComponent('mail::message'); ?>
<div>
    <h1>
        Hello,
        <?php echo e(' ' .$username); ?></h1>
    <p> Your unique order number is:
        <?php echo e($order->id); ?></p>
    <p>This was placed at: <?php echo e($order->updated_at); ?></p>
    <br />
    <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($book->name); ?><?php echo " X " ?><?php echo e($book->pivot->quantity); ?> =£ <?php echo e($book->pivot->sub_total); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br />
    <h1>Order Total: £<?php echo e($order->total); ?></h1>

    Thanks for your order,
    <br>
</div>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/emails/receipt.blade.php ENDPATH**/ ?>