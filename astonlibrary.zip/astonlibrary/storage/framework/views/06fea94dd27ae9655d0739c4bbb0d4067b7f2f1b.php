<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php if($order): ?>
<div class="container text-center card bg-dark">
    <div class="row">
        <div class="card-body ">
            <h3 class="card-title">Order summary:</h3>
            <h5 class="card-title"><?php echo e($order->user->email); ?></h5>
            <div class="card-text">
                <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>
                    <h4>
                        <?php echo e($book->name); ?> X
                        <?php echo e($book->pivot->quantity); ?>

                    </h4>
                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="card-body">
        <h1>Total : £<?php echo e($order->total); ?></h1>
    </div>
    <div class="card-body ">
        <form action="<?php echo e(route('order.store',$order)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="email">Enter the email address you want the receipt sending too</label>
            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                value="<?php echo e($order->user->email); ?>" autocomplete="email">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </br>
            <a href="<?php echo e(route('admin.books.index')); ?>" type="button" class="btn btn-block btn-secondary">Continue
                Shopping</a>
            <button type="submit" class="btn btn-block btn-primary">Complete purchase</button>
        </form>
    </div>
</div>
<?php else: ?>
<div class="container text-center card bg-dark">
    <h1> Nothing in your basket! </h1>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/order/create.blade.php ENDPATH**/ ?>