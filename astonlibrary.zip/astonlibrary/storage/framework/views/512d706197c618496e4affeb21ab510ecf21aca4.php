<?php $__env->startSection('content'); ?>
<div class="container card bg-dark text-white">
  <?php 
    if($book->images() != null){
        $images = $book->images()->get()->pluck('name');
    }
    ?>
  <div id="carouselExampleControls" class="carousel slide center row col-4 d-flex justify-content-center" data-ride="carousel"
    style="height:10vh;overflow:hidden;">
    <div class="carousel-inner container">
      <?php if(!empty($images)): ?>
      <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($image==$images[0]): ?>
      <div class="carousel-item active">
        <img style="padding-top:3%;padding-left" class="d-block w-100 img-fluid"
          src="https://astonbookstore.s3.eu-west-2.amazonaws.com/<?php echo e($image); ?>" alt="pic">
      </div>
      <?php else: ?>
      <div class="carousel-item">
        <img class="d-block w-100 img-fluid" src="https://astonbookstore.s3.eu-west-2.amazonaws.com/<?php echo e($image); ?>" alt="pic">
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
  <h1 class="card-header"><?php echo e($book->name); ?></h1>
  <div class="card-body">
    <p>Published in year <?php echo e($book->published_year); ?></p>
    <h1 class="card-title"><?php echo e(implode(', ' ,$book ->authors()->get()->pluck('name')->toArray())); ?></h1>
    <h5 class="card-title"><?php echo e(implode(', ' ,$book ->categories()->get()->pluck('name')->toArray())); ?></h5>
    <div class="row">
      <h4 class="card-text col-xs-12 col-sm-6">£<?php echo e($book->price); ?></h4>
      <h5 class="card-text col-xs-12 col-sm-6 ">There is <?php echo e($book->stock); ?> left in stock</h5>
    </div>
    <div class="row">
      <p class="card-text"><?php echo e($book->description); ?></p>
    </div>
    <div class="card-footer">
      <?php if(auth()->guard()->check()): ?>
      <form method="POST" action="<?php echo e(route('order.add',$book->id)); ?>">
        <?php echo csrf_field(); ?>
        <label for="stock">Quantity</label>
        <div class="input-group mb-3">
          <input required name="quantity" pattern="^[0-9]*$" class="form-control" type="number" min="0" step="1"
            max="1000" value="1" />
          <div class="input-group-append">
            <button type="submit" class="btn btn-success">Add to basket</button>
          </div>
        </div>

      </form>
      <?php endif; ?>
      <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-block">Back</a>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/admin/books/show.blade.php ENDPATH**/ ?>