<?php echo e($slot); ?>

<?php /**PATH /home/u-180203857/astonlibrary/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>