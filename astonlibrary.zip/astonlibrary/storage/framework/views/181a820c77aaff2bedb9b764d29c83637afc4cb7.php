<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark text-white">
                <div class="card-header">users</div>

                <div class="card-body">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?></th>
                                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
                                <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>
                                <th scope="col">Role(s)</th>
                                <?php if(Auth::user()->can('edit-users') and Auth::user()->can('delete-users')): ?>
                                <th></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($user->id); ?></th>
                                <td><?php echo e($user ->name); ?></td>
                                <td><?php echo e($user ->email); ?></td>
                                <td><?php echo e(implode(', ' ,$user ->roles()->get()->pluck('name')->toArray())); ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-users')): ?>
                                <td>
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><button type="button"
                                            class="btn btn-primary float-left ">Edit</button></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-users')): ?>
                                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST"
                                        class="float-left" name="delete_user">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo $users->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views//admin/users/index.blade.php ENDPATH**/ ?>