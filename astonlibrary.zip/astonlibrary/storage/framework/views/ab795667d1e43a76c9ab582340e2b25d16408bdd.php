<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container">
    <div class="card bg-dark text-white">
        <h5 class="card-header"><?php echo e(Auth::user()->name); ?></h5>
        <?php if(!$order->books->count()): ?>
        <div class="card-body text-center">
            <h1>Basket is empty</h1>
            <span class="material-icons">
                shopping_basket
            </span>
        </div>
        <?php else: ?>
        <div class="card-body">
            <h5 class="card-title">Order details <?php echo e($order->id); ?></h5>
            <div class="row">
                <div class="col">
                    Title
                </div>
                <div class="col">
                    Price
                </div>
                <div class="col">
                    Quantity
                </div>
                <div class="col">
                    Sub Total
                </div>
                <div class="col">

                </div>
            </div>
            <?php $__currentLoopData = $order->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('order.update',$order)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <!-- <form  action="<?php echo e(route('order.update',$order)); ?>" method="POST"> -->
                <div class="row">
                    <div class="col">
                        <?php echo e($book->name); ?>

                    </div>
                    <div class="col">
                        £<?php echo e($book->price); ?>

                    </div>

                    <div class="col">
                        <input type="hidden" name="bookid" value="<?php echo e($book->id); ?>" />
                        <input required name="quantity" pattern="^[0-9]*$" class="form-control" type="number" min="1"
                            step="1" max="<?php echo e($book->stock); ?>" value="<?php echo e($book->pivot->quantity); ?>" />
                    </div>
                    <div class="col">
                        <?php echo e($book->pivot->sub_total); ?>

                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary">
                            Update
                        </button>
            </form>
            <form action="<?php echo e(route('order.remove', $order->id)); ?>" method="POST" class="float-left" name="delete_book">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('POST')); ?>

                <input type="hidden" name="bookid" value="<?php echo e($book->id); ?>" />
                <input type="hidden" name="quantity" value="<?php echo e($book->pivot->quantity); ?>" />
                <input type="hidden" name="sub_total" value="<?php echo e($book->pivot->sub_total); ?>" />
                <button type="submit" class="btn btn-danger">Remove</button>
            </form>
        </div>
    </div>
    <!--</form> -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h1> Total : <?php echo e(utf8_encode("�")); ?> <?php echo e($order->total); ?></h1>
    <a type="button" href="<?php echo e(route('order.create')); ?>" class="btn btn-primary">Proceed to checkout</a>

</div>
</div>
<?php endif; ?>
<br/>
<a type="button" href="<?php echo e(route('order.index')); ?>" class="btn btn-primary btn-block">View previous orders</a>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/order/show.blade.php ENDPATH**/ ?>