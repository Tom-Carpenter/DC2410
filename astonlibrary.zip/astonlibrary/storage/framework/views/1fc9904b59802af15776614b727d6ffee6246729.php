<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
  <?php if(!$filtered): ?>
  <button type="button" class="btn btn-block btn-primary" data-toggle="modal" data-target="#filterModal">
    Filter results
  </button>
  <?php endif; ?>
  <?php if($filtered==true): ?>
  <form action="<?php echo e(route('admin.books.index')); ?>">
    <button type="submit" class="btn btn-block btn-danger">
      Clear filter
    </button>
  </form>
  <?php endif; ?>
  <!-- modal filter panel -->
  <div class="modal fade " id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg ">
      <div class="modal-content bg-dark">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Filter orders</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('admin.books.index')); ?>" method="GET">
          <div class="modal-body card card-body bg-dark text-light">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="filter" value="<?php echo e(true); ?>" />
            <div class="form-group">
              <label for="name">Name</label>
              <input id="name" name="name" type="name" class="form-control" />
            </div>
            <div class="form-group">
              <label for="description">Filter by cost less than (GBP)</label>
              <input name="price_lower" class="form-control" type="number" min="0.00" step="1.00" max="2500" />
            </div>
            <div class="form-group">
              <label for="description">Filter by cost greater than (GBP)</label>
              <input name="price_upper" class="form-control" type="number" min="0.00" step="1.00" max="2500" />
            </div>
            <div class="form-group">
              <label for="year_start">Year published between </label>
              <input type="date" id="year_start" name="year_start">
              <label for="year_end">and (if blank assumed as <?php echo e(date('Y')); ?> )</label>
              <input type="date" id="year_end" name="year_end">
            </div>
            <div class="form-group">
              <label for="author">Select an author:</label>
              <select class="form-control" name="author" id="author">
                <option value="<?php echo e(null); ?>">No selection</option>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($author->id); ?>"><?php echo e($author->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="category">Select an category:</label>
              <select class="form-control" name="category" id="category">
                <option value="<?php echo e(null); ?>">No selection</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-block btn-primary">Filter</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <table class="table table-dark table-striped">
    <thead>
      <tr>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id'));?> </th>
        <!-- <th scope="col">picture carousel column</th> -->
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name'));?></th>
        <th scope="col">Description</th>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price'));?></th>
        <th scope="col">Categories</th>
        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('stock'));?></th>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-books')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-books')): ?>
        <th scope="col"> Actions </th>
        <?php endif; ?>
        <?php endif; ?>

      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($book->id); ?></th>
        <td><a class="text-info" href="<?php echo e(route('admin.books.show',$book->id)); ?>"><?php echo e($book->name); ?></a></td>
        <td><?php echo e($book->description); ?></td>
        <td><?php echo e($book->price); ?></td>
        <td>
          <?php echo e(implode(', ' ,$book ->categories()->get()->pluck('name')->toArray())); ?>

        </td>
        <td><?php echo e($book->stock); ?></td>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-books')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-books')): ?>
        <td>
          <a class="text-light" href="<?php echo e(route('admin.books.edit', $book)); ?>"><button type="button"
              class="btn btn-block btn-primary float-left ">Edit</button></a>
</div>
<!--
            <form action="<?php echo e(route('admin.books.destroy', $book)); ?>" method="POST" class="float-left" name="delete_book">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <button type="submit" class="btn btn-block btn-danger">Delete</button> -->
<!-- dont think i want anyone to delete a book -->
</form>
</td>

<?php endif; ?>
<?php endif; ?>
</tr>
</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $books->appends(request()->query())->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-180203857/astonlibrary/resources/views/admin/books/index.blade.php ENDPATH**/ ?>